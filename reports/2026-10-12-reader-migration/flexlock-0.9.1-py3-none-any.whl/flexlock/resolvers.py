"""OmegaConf resolvers for FlexLock."""

from omegaconf import OmegaConf, DictConfig
from .data_hash import hash_data
from .load_stage import load_stage_from_path
from datetime import datetime
from contextlib import contextmanager
import re
from pathlib import Path
from functools import wraps
from contextvars import ContextVar
from copy import deepcopy
import hashlib
import json
from . import config

# Resolvers whose evaluation is *deferred* to stage start (they read live
# filesystem/upstream-run state that only exists on the worker, not at submit
# time). During the submit-time freeze these are stubbed to re-emit their own
# call string (see ``deferred_stubbed``); everything else resolves eagerly.
DEFERRED_RESOLVERS = ("run_lock", "latest")

# Distinct "no default supplied" sentinel so that an explicit ``null`` default
# (e.g. ``${run_lock:${dir},key,null}``) is honoured rather than treated as
# "raise". ``None`` cannot serve as this marker because it is a valid default.
_MISSING = object()
_run_lock_capture = ContextVar('flexlock_run_lock_capture', default=None)


class _RunLockCapture:
    """One coherent read of each producer during one stage resolution."""
    def __init__(self):
        self.records = {}
        self.digests = {}
        self.reads = []
        self.seen_reads = set()

    def load(self, path):
        from .record import load_record
        if path not in self.records:
            self.records[path] = load_record(path)
            self.digests[path] = (hashlib.sha256(json.dumps(
                self.records[path], sort_keys=True, default=str).encode()).hexdigest()
                if self.records[path] is not None else None)
        return self.records[path]

    def record(self, path, key, value, used_default):
        entry = dict(path=path, field=key, value=deepcopy(value),
                     used_default=used_default, record_sha256=self.digests[path])
        identity = json.dumps(entry, sort_keys=True, default=str)
        if identity not in self.seen_reads:
            self.reads.append(entry)
            self.seen_reads.add(identity)



def now_resolver(fmt: str = None) -> str:
    """
    OmegaConf resolver that returns the current time as a formatted string.

    Deprecated: prefer ``submit(..., save_dir_policy="timestamp")`` over
    embedding ``${now:}`` in ``save_dir``. See
    ``docs/resolution_simplification_plan.md``.

    Args:
        fmt: Format string for strftime (defaults to config.TIMESTAMP_FORMAT)
    """
    import warnings

    warnings.warn(
        "${now:} is deprecated; use save_dir_policy='timestamp' on submit()/run "
        "instead of embedding ${now:} in save_dir.",
        DeprecationWarning,
        stacklevel=2,
    )
    if fmt is None:
        fmt = config.TIMESTAMP_FORMAT
    return datetime.now().strftime(fmt)


def latest_resolver(path_glob: str, default=_MISSING) -> str:
    """
    OmegaConf resolver that returns the latest path matching the given pattern.

    Raises ``FileNotFoundError`` when nothing matches, unless a ``default`` is
    supplied (``${latest:pattern,fallback}``), in which case the default is
    returned. Returning the unmatched pattern silently — the old behaviour —
    produced a bogus path that failed far downstream.
    """
    from glob import glob
    import os

    # Expand user (~) and resolve the path
    path_glob = os.path.expanduser(path_glob)

    # Find all paths matching the pattern
    matching_paths = glob(path_glob, recursive=True)

    if not matching_paths:
        if default is not _MISSING:
            return default
        raise FileNotFoundError(
            f"latest resolver: no paths match pattern {path_glob!r}"
        )

    # Find the latest path by modification time
    latest_path = max(matching_paths, key=os.path.getmtime)

    return latest_path


def vinc_resolver(path: str, fmt: str = "_{i:04d}") -> str:
    """
    OmegaConf resolver that finds the highest existing version of a folder/file
    and returns the next versioned path as a string.

    The value is a pure function of the current filesystem state (highest
    existing version + 1) so that multiple references to the same ``${vinc:}``
    within one ``submit()`` resolve idempotently to the *same* directory — the
    counter only advances once the previous run's directory actually exists on
    disk.

    Concurrency note: because the claim is not taken here, two submits racing
    from separate processes can compute the same next version and collide.

    Deprecated: prefer ``submit(..., save_dir_policy="increment")``, which takes
    the atomic ``mkdir(exist_ok=False)`` claim at the right layer and so fixes
    the race this resolver could not. See ``docs/resolution_simplification_plan.md``.
    """
    import warnings

    warnings.warn(
        "${vinc:} is deprecated; use save_dir_policy='increment' on submit()/run "
        "instead of embedding ${vinc:} in save_dir. The policy also claims the "
        "directory atomically, fixing the concurrent-submit race.",
        DeprecationWarning,
        stacklevel=2,
    )
    from .save_dir import next_versioned_path

    return next_versioned_path(path, fmt)


def run_lock_resolver(run_dir: str, key: str, default=_MISSING):
    """
    OmegaConf resolver that reads a field from an upstream run.lock.

    Navigates a dot-separated key path into the run.lock YAML and returns
    the value with its native type (int, float, bool, str, list, dict).

    Usage in configs:
        ${run_lock:path/to/run_dir,config.datamodule.stats_file}
        ${run_lock:${run_dir},config.lit_module.regression_checkpoint_path,null}
    """
    from loguru import logger

    from .record import load_record

    capture = _run_lock_capture.get()
    path = str(Path(run_dir).resolve())
    data = capture.load(path) if capture is not None else load_record(path)
    def finish(value, used_default=False):
        if capture is not None:
            capture.record(path, key, value, used_default)
        return value
    if data is None:
        if default is not _MISSING:
            logger.warning(f"run_lock resolver: no run.lock at {run_dir}, using default")
            return finish(default, used_default=True)
        raise FileNotFoundError(
            f"run_lock resolver: no run.lock found in {run_dir} "
            f"(nor a sweep-task record)"
        )

    # Navigate dot-path
    value = data
    for part in key.split("."):
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            if default is not _MISSING:
                return finish(default, used_default=True)
            raise KeyError(
                f"run_lock resolver: key '{key}' not found in the run record at {run_dir} "
                f"(failed at '{part}')"
            )

    if value is None:
        # A legitimately null value is returned as-is when no default was
        # supplied; only substitute an explicitly provided default.
        return finish(None if default is _MISSING else default, used_default=default is not _MISSING)
    return finish(value)


def run_resolver(address, select=None, pin=None, strict=None) -> str:
    """``${run:<preset>[,<select>[,<pin>[,strict]]]}`` → newest complete run dir.

    See :func:`flexlock.presets.resolve_run`. Bound by ``freeze_run_refs`` at
    submit, or at worker stage start for unpinned scheduler-chain references.
    """
    from .presets import resolve_run

    return resolve_run(address, select, pin, strict)


def register_resolvers():
    """
    Registers the flexlock resolvers with OmegaConf.
    """
    OmegaConf.register_new_resolver("now", now_resolver)
    OmegaConf.register_new_resolver("vinc", vinc_resolver)
    OmegaConf.register_new_resolver("latest", latest_resolver, use_cache=False)
    OmegaConf.register_new_resolver("run_lock", run_lock_resolver, use_cache=False)
    OmegaConf.register_new_resolver("run", run_resolver, use_cache=False)


# The real resolver implementations plus their registration options, so a stub
# context can faithfully restore them on exit.
def _real_resolvers():
    return {
        "now": (now_resolver, {}),
        "vinc": (vinc_resolver, {}),
        "latest": (latest_resolver, {"use_cache": False}),
        "run_lock": (run_lock_resolver, {"use_cache": False}),
        "run": (run_resolver, {"use_cache": False}),
    }


def _emit_stub_arg(value) -> str:
    """Render a (pre-resolved) resolver argument back into interpolation text.

    ``None`` becomes ``null`` so a real ``${run_lock:${dir},key,null}`` default
    survives the freeze; everything else is stringified as-is.
    """
    if value is None:
        return "null"
    return str(value)


@contextmanager
def _stubbed(names):
    """Temporarily replace the named resolvers with stubs that re-emit their own
    call string, with arguments already resolved by OmegaConf.

    OmegaConf resolves nested interpolations in a resolver's arguments *before*
    invoking the resolver. So under this context, resolving
    ``${run_lock:${precompute_dir},key}`` yields the frozen string
    ``${run_lock:/data/precomputed,key}`` — every non-stubbed interpolation
    (simple refs, cross-tree, multi-hop, mixed strings, relative refs) is
    resolved by OmegaConf itself, while the stubbed call collapses back to a
    self-contained call string with zero hand-rolled grammar parsing.

    Restores the real resolvers (with their original options) on exit.
    """
    def _make_stub(name):
        def _stub(*args):
            return "${" + name + ":" + ",".join(_emit_stub_arg(a) for a in args) + "}"
        return _stub

    reals = _real_resolvers()
    for name in names:
        OmegaConf.register_new_resolver(
            name, _make_stub(name), replace=True, use_cache=False
        )
    try:
        yield
    finally:
        for name in names:
            func, opts = reals[name]
            OmegaConf.register_new_resolver(name, func, replace=True, **opts)


@contextmanager
def defer_unpinned_runs(enabled=True):
    """Preserve unpinned run calls while still resolving explicit pins."""
    if not enabled:
        yield
        return

    def resolver(*args):
        pin = args[2] if len(args) > 2 else None
        if pin is not None and str(pin).strip().lower() not in ("", "strict"):
            return run_resolver(*args)
        return "${run:" + ",".join(_emit_stub_arg(a) for a in args) + "}"

    OmegaConf.register_new_resolver("run", resolver, replace=True, use_cache=False)
    try:
        yield
    finally:
        OmegaConf.register_new_resolver("run", run_resolver, replace=True, use_cache=False)


def deferred_stubbed(defer_runs=False):
    """Stub only the deferred resolvers (``run_lock``/``latest``).

    Used by the merge-before-resolve sweep freeze, where ``vinc``/``now`` should
    still fire (they are being retired via ``save_dir_policy``).
    """
    return _stubbed(DEFERRED_RESOLVERS + (("run",) if defer_runs else ()))


def frozen_resolvers():
    """Stub every flexlock resolver, so all ``${name:args}`` calls are preserved
    as frozen call strings during the submit-time node freeze.
    """
    return _stubbed(tuple(_real_resolvers().keys()))


def _attach_run_lock_capture(resolved, capture, *, binding=None):
    if not capture.reads:
        return
    snap = resolved.setdefault('_snapshot_', {})
    reads = snap.setdefault('run_lock_reads', [])
    for entry in capture.reads:
        if binding:
            entry['binding'] = binding
        if entry not in reads:
            reads.append(entry)
    records = snap.setdefault('run_lock_records', {})
    records.update({
        path: {key: deepcopy(record[key]) for key in
               ('config', 'timestamp', 'repos', 'parent', 'fingerprint', 'task_id', 'record_dir')
               if key in record}
        for path, record in capture.records.items() if record is not None
    })


def bind_existing_run_locks(cfg: DictConfig, *, allow_future=False, future_paths=()) -> DictConfig:
    """Freeze concrete existing producer reads before dispatch.

    Missing required producers may remain deferred only for an explicit future
    workflow. Other resolver calls stay untouched. Each selected producer is read
    once and its full record identity is checked again at stage start.
    """
    detached = OmegaConf.create(OmegaConf.to_container(cfg, resolve=False))
    return _bind_detached_run_locks(detached, allow_future=allow_future,
                                    future_paths=future_paths)


def _bind_detached_run_locks(detached, *, allow_future=False, future_paths=()):
    """Binding implementation for an already detached, privately owned config."""
    capture = _RunLockCapture()
    future_paths = {str(Path(path).resolve()) for path in future_paths}

    def bind(run_dir, key, default=_MISSING):
        # A deferred selection is a compatibility path, not a concrete producer.
        if '${' in str(run_dir):
            if not allow_future:
                raise ValueError('run_lock requires a concrete producer path before dispatch')
            return '${run_lock:' + ','.join(_emit_stub_arg(a) for a in
                ((run_dir, key) if default is _MISSING else (run_dir, key, default))) + '}'
        path = str(Path(run_dir).resolve())
        if default is _MISSING:
            from .destination_guard import has_active_destination
            if has_active_destination(path):
                if not allow_future:
                    from .exceptions import FlexLockValidationError
                    raise FlexLockValidationError(
                        f"Selected producer has pending/running work: {path}. "
                        "Pair its concrete path with after/--after."
                    )
                return '${run_lock:' + ','.join(_emit_stub_arg(a) for a in (path, key)) + '}'
        if capture.load(path) is None and default is _MISSING and (allow_future or path in future_paths):
            return '${run_lock:' + ','.join(_emit_stub_arg(a) for a in (path, key)) + '}'
        # Escape literal interpolation syntax returned by a real producer, while
        # leaving deliberate future resolver calls live.
        return _escape_literals(run_lock_resolver(run_dir, key, default))

    token = _run_lock_capture.set(capture)
    try:
        with _stubbed(tuple(name for name in _real_resolvers() if name not in ('run_lock', 'latest'))):
            OmegaConf.register_new_resolver('run_lock', bind, replace=True, use_cache=False)
            try:
                resolved = OmegaConf.to_container(detached, resolve=True)
            finally:
                OmegaConf.register_new_resolver('run_lock', run_lock_resolver,
                                                replace=True, use_cache=False)
    finally:
        _run_lock_capture.reset(token)
    _attach_run_lock_capture(resolved, capture, binding='submit')
    if capture.reads:
        for key in ('run_lock_reads', 'run_lock_records'):
            resolved['_snapshot_'][key] = _escape_literals(resolved['_snapshot_'][key])
    return OmegaConf.create(resolved)


def _verify_submit_bindings(cfg):
    from .exceptions import FlexLockValidationError

    raw = OmegaConf.to_container(cfg, resolve=False)
    snap = raw.get('_snapshot_') or {}
    capture = _RunLockCapture()
    for entry in snap.get('run_lock_reads', []):
        if entry.get('binding') != 'submit':
            continue
        path = entry['path']
        capture.load(path)
        if capture.digests[path] != entry['record_sha256']:
            raise FlexLockValidationError(
                f"Selected producer record changed or disappeared after submission: {path}. "
                "Use a fresh producer path or resubmit after reviewing the replacement."
            )


def resolve_deferred(cfg: DictConfig) -> DictConfig:
    """Verify submit bindings, then resolve promised producers at stage start."""
    _verify_submit_bindings(cfg)
    capture = _RunLockCapture()
    token = _run_lock_capture.set(capture)
    try:
        resolved = OmegaConf.to_container(cfg, resolve=True, throw_on_missing=False)
    finally:
        _run_lock_capture.reset(token)
    _attach_run_lock_capture(resolved, capture)
    return OmegaConf.create(_escape_literals(resolved))


def _escape_literals(value):
    """Re-escape ``${`` in already-resolved values before re-wrapping.

    After a full resolve, a string can only still contain ``${`` if it was an
    escaped literal (backslash-escaped interpolation) or a resolver's output. Re-wrapping it in a
    fresh config would turn it back into a live interpolation, so escape it.
    """
    if isinstance(value, str):
        return value.replace("${", "\\${") if "${" in value else value
    if isinstance(value, dict):
        return {k: _escape_literals(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_escape_literals(v) for v in value]
    return value
